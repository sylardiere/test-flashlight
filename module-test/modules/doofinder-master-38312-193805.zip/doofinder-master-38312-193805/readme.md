# validation-platform-assets

This repository is used to store the github action for call the validator linked to the platform-validation project.
<br>
It allows you to receive the validator's feedback when a contributor submits a module.
<br>
In order to avoid that the github action starts in this repository, we have modified the directory from .github to github.
If you want to clone this repository and use the github action remember to put the directory as a cache directory.
Link : https://github.com/PrestaShopCorp/validation-platform