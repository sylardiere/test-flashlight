<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{doofinder}prestashop>doofinder_dd31d974a78cdd704acaa6bf15da506c'] =
'Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_537d60a5ce0c6b6cf2d6790d5b38b93f'] =
'Agregue un motor de búsqueda inteligente a su comercio electrónico en 5 minutos y sin programación';
$_MODULE['<{doofinder}prestashop>doofinder_e499922a91899a55af0659f1f4772e6a'] =
'¿Estás seguro? Esto no cancelará tu cuenta con Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_4b87741739092ad3d8ebedd16f51b8fa'] =
'Capa de búsqueda de Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_51c17cc3a1f109327c91c2bab0e21962'] =
'Capa de búsqueda de Doofinder en versión móvil';
$_MODULE['<{doofinder}prestashop>doofinder_79958197e198decc81fe8357f5e18a56'] =
'Store ID de Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_a0d5c74d196e9447e43b5d35875172dd'] =
'Puedes encontrar este identificador en nuestro Panel de Control, dentro del menú superior etiquetado como \"Live Layer\"';
$_MODULE['<{doofinder}prestashop>doofinder_652f52b24a21bd5ff556daeb1c23e304'] =
'Capa de búsqueda';
$_MODULE['<{doofinder}prestashop>doofinder_ac094819c47414b269d824497c1ff3ec'] =
'Guardar opciones de capa de búsqueda';
$_MODULE['<{doofinder}prestashop>doofinder_daae36229556815de2395abf51714337'] =
'Feed de datos';
$_MODULE['<{doofinder}prestashop>doofinder_c5848d64c88f4174aa2c7a25d06bc044'] =
'Indexar los precios de los productos';
$_MODULE['<{doofinder}prestashop>doofinder_79272d6ac0fc6480115ee98565778947'] =
'Si activas esta opción podrás mostrar los precios de cada producto en los resultados de búsqueda.';
$_MODULE['<{doofinder}prestashop>doofinder_2e50fba97feb0e9b740a5c785d07ab7d'] =
'Mostrar los precios de los productos con impuestos incluidos';
$_MODULE['<{doofinder}prestashop>doofinder_11a4b29c886f33dc95b29c02318e179f'] =
'Si activas esta opción, el precio de los productos que se mostrará será con impuestos ya incluidos';
$_MODULE['<{doofinder}prestashop>doofinder_73c34b49888ccdf22dd73e7eafc0edd8'] =
'Indexar la ruta completa de la categoría de productos';
$_MODULE['<{doofinder}prestashop>doofinder_cdfda1adef135661c21a248cb159c6f4'] =
'Indexar las combinaciones de atributos de los productos';
$_MODULE['<{doofinder}prestashop>doofinder_e730c40ec1617ecf160fa29d8a1dc05c'] =
'Define por qué combinaciones de atributos de los productos quieres indexar';
$_MODULE['<{doofinder}prestashop>doofinder_bbf76abf65b7e5530ebf33b0f8a666c9'] =
'Indexar caracteristicas personalizadas de los productos';
$_MODULE['<{doofinder}prestashop>doofinder_ebe75aa799359b32559a09eae8594835'] =
'Seleccionar las características que serán mostradas en el feed';
$_MODULE['<{doofinder}prestashop>doofinder_90dce1b992114b5c7ab37ee99ea195ec'] =
'Tamaño de la imagen de producto';
$_MODULE['<{doofinder}prestashop>doofinder_435374cdbc1c2cf3b63e9775cbedd00a'] =
'Procesar automáticamente las modificaciones de los productos';
$_MODULE['<{doofinder}prestashop>doofinder_c2cad3c344198599b69e25634315170d'] =
'Configurar cuándo se envían los cambios de productos registrados a Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_48bf14c419a1d441412510faf39c326d'] =
'Cada día';
$_MODULE['<{doofinder}prestashop>doofinder_643bd9766a482fed97aff60a7a4f1b3b'] =
'Cada %s minutos';
$_MODULE['<{doofinder}prestashop>doofinder_836f443d97d58d8ec45b18fd574c8933'] =
'Guardar opciones del feed';
$_MODULE['<{doofinder}prestashop>doofinder_9dfc5d5738312210c3c75e68a468691d'] =
'Opciones Avanzadas';
$_MODULE['<{doofinder}prestashop>doofinder_e0daaf59114081fac112928e638c8d85'] =
'Doofinder Api Key';
$_MODULE['<{doofinder}prestashop>doofinder_f447ac856e7e72435904956e3b15f433'] =
'Región';
$_MODULE['<{doofinder}prestashop>doofinder_c01ae558981823abcbd1489ac81f6fc9'] =
'Habilitar layer v9 (Livelayer)';
$_MODULE['<{doofinder}prestashop>doofinder_f4f6f81745dcb96aaf1cd38461ba2356'] =
'Modo depuración. Escribe logs de información en el fichero doofinder.log';
$_MODULE['<{doofinder}prestashop>doofinder_b0939b990335e5c6a8f76fa5c81835b3'] =
'Desactivar comprobación HTTPS en el CURL';
$_MODULE['<{doofinder}prestashop>doofinder_8391131ea151a1b120d9fceef5ad9b9a'] =
'Si tu servidor tiene un certificado inválido y tienes problemas con la API, por favor activa esto';
$_MODULE['<{doofinder}prestashop>doofinder_bfa398fb4ff673ac66baeedbc80f0b77'] =
'Depurar respuesta de error en el CURL';
$_MODULE['<{doofinder}prestashop>doofinder_170246e7e517d7cd317e3a6ae3ebcb4c'] =
'Para depurar si tu servidor tiene problemas de conexión';
$_MODULE['<{doofinder}prestashop>doofinder_48c07cbd1f0f4b03d59befc3e72e9b87'] =
'Guardar opciones de búsqueda interna';
$_MODULE['<{doofinder}prestashop>doofinder_fcea235fdf24a526070153f5b60355f4'] =
'Acabas de cambiar una opción del feed de datos. Es posible que para aplicar estos cambios de manera efectiva sea necesario volver a procesar el índice.';
$_MODULE['<{doofinder}prestashop>doofinder_2378c5bcb7b183304da2a2b94262f024'] =
'Lanzar reindexación';
$_MODULE['<{doofinder}prestashop>doofinder_039b452cd9646bf1a60dd09146311ee7'] =
'La configuración se guardó correctamente.';
$_MODULE['<{doofinder}prestashop>doofinder_00d23a76e43b46dae9ec7aa9dcbebb32'] =
'Activado';
$_MODULE['<{doofinder}prestashop>doofinder_b9f5c797ebbf55adccdd8539a65a0241'] =
'Desactivado';
$_MODULE['<{doofinder}prestashop>configure_ba0801f239c99cb689010161d3ee1471'] =
'Comenzando';
$_MODULE['<{doofinder}prestashop>configure_8cd892b7b97ef9489ae4479d3f4ef0fc'] =
'tienda';
$_MODULE['<{doofinder}prestashop>configure_db5eb84117d06047c97c9a0191b5fffe'] =
'Soporte';
$_MODULE['<{doofinder}prestashop>configure_9b6545e4cea9b4ad4979d41bb9170e2b'] =
'Avanzado';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_86bbc77fd75ac02c21b84a37b260eadd'] =
'Panel de administración';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_23693319f4ed79081952f04729017d15'] =
'Configurar Doofinder en mi tienda';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_f6e6bc175f0485d397ee4c1d45c1d01e'] =
'Accede al panel de Doofinder y descubre todas las funcionalidades para aumentar tus ventas.';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_e77e4aaa7a0d7df358c2f9a8276bee7d'] =
'Ir al panel de Doofinder';
$_MODULE['<{doofinder}prestashop>feed_url_partial_tab_08c1cf7707bb72744cd07192c8580580'] =
'URLs de los feeds para usar en el Dashboard de Doofinder';
$_MODULE['<{doofinder}prestashop>feed_url_partial_tab_c2052eaf6f39b73a2c74240459fc2615'] =
'URL del feed de datos para';
$_MODULE['<{doofinder}prestashop>indexation_status_51160de843c8d9ed5564f4f26208c02e'] =
'Estado de la indexación de Doofinder';
$_MODULE['<{doofinder}prestashop>indexation_status_b1d48d617a09cbe4e68eb72c83dea83d'] =
'El feed de productos está siendo procesado. Dependiendo del tamaño del catálogo de productos de la tienda, este proceso puede llevar unos minutos';
$_MODULE['<{doofinder}prestashop>indexation_status_e0dba0265fde532f75126eab6fedb8a8'] =
'Es posible que sus productos no aparezcan correctamente actualizados en los resultados hasta que el proceso no haya finalizado.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_6b866b4e92effe404fd83e7a7885ad19'] =
'Éxito al conectar con Doofinder.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_deed258a0a8c1f5382450930479ac0fd'] =
'No puedes conectarte con Doofinder. Ponte en contacto con tu proveedor de servidor para verificar la conexión a Internet o el firewall de tu servidor web.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_a4a6b90012834c7cb676c674bf621993'] =
'Se ha producido un error durante la instalación. Por favor, contacta con nuestro equipo  de soporte a través de';
$_MODULE['<{doofinder}prestashop>onboarding_tab_747e44b01e24ca919d59438ae296b448'] =
'Creando los motores de búsqueda...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f7c1251d5362d2d5d94acc2032a50484'] =
'Recopilando los catálogos de productos...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_3339a7d2f65d221bf59b9c25581966f1'] =
'Creando índices de búsqueda en el sitio web...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_44665e4612000577ba603412b3aa25b2'] =
'Dando el último toque mágico final...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_659ae688646b0c710802028d1bbc2812'] =
'Recargando la página, por favor espere...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_c594c7071a3f319fc4db4fa2a6e83f5b'] =
'Crear esta tienda en Doofinder';
$_MODULE['<{doofinder}prestashop>onboarding_tab_7edaed702d94d2c7807d20d662c7067a'] =
'Ya tengo cuenta';
$_MODULE['<{doofinder}prestashop>onboarding_tab_4d6db8d5a88bb9c3e6b55bce672e0dd9'] =
'Quiero omitir la autoinstalación, llévame a la configuración manual del módulo.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_ba26552e526b4e94f440ab5a0f7ce65f'] =
'Agregue un motor de búsqueda inteligente a su comercio electrónico en 5 minutos y  sin programación.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_1e084cd6e247c0daa8f4004976a10df5'] =
'ACERCA DE DOOFINDER';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f770abcb4ee19d99e1dfa65fe2504e18'] =
'Entre nuestras características están';
$_MODULE['<{doofinder}prestashop>onboarding_tab_fa48c4bc8e56055f4501cab8d53ce068'] =
'Informes detallados sobre el comportamiento de búsqueda de visitantes';
$_MODULE['<{doofinder}prestashop>onboarding_tab_4562bb888773ad94e6c7e0c2083d8c79'] =
'Opción de búsqueda facetada';
$_MODULE['<{doofinder}prestashop>onboarding_tab_c17910ea7aaac1591ce9f5485f657f4f'] =
'Aprende el comportamiento de los usuarios';
$_MODULE['<{doofinder}prestashop>onboarding_tab_907d3b76d74e77bc7ded86a5e61a0e88'] =
'Potencia la comercialización para establecer el posicionamiento de un producto';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f06602764717ea3114175e3e5039a42a'] =
'Posibilidad de agregar  (añadir, insertar) banners para publicidad y promoción de productos,  marcas y eventos';
$_MODULE['<{doofinder}prestashop>onboarding_tab_484ebd8da685828c8892dbbb1a570f89'] =
'Opciones para redirigir a los usuarios a páginas de contenido';
$_MODULE['<{doofinder}prestashop>onboarding_tab_8e94cbfc7639e8d47a939179b12a8eac'] =
'Mantenido en nuestros servidores para un tiempo de carga de página más rápido';
$_MODULE['<{doofinder}prestashop>onboarding_tab_18947c4da2bdf6834e993001d003293d'] =
'Más de 5000 sitios de comercio electrónico en más de 35 países ya lo están utilizando';
$_MODULE['<{doofinder}prestashop>onboarding_tab_d3de93cac749c0caa87290a2a4a7c8a9'] =
'¿Que estas esperando?';
$_MODULE['<{doofinder}prestashop>support_tab_4c1fee9a2c61bba0f4bbcab7c99948de'] =
'¿Necesitas ayuda para configurar tu motor de búsqueda?';
$_MODULE['<{doofinder}prestashop>support_tab_dfc465ee578939c8760c4aa00d2c7234'] =
'¡Toda la documentación en un sitio!';
$_MODULE['<{doofinder}prestashop>support_tab_a0b0d4b4cb7e019561740ca1fe2e9a4a'] =
'Entender cómo funciona el feed de productos para mostrar los resultados en la capa de búsqueda de Doofinder';
$_MODULE['<{doofinder}prestashop>support_tab_6b8f482bb34c8983f0bcb2651b776e9f'] =
'Cómo añadir información en la capa de búsqueda de Doofinder';
$_MODULE['<{doofinder}prestashop>support_tab_105dad09bf429ff180f1465aba5b2164'] =
'Cómo configurar los filtros de la capa de búsqueda';
$_MODULE['<{doofinder}prestashop>support_tab_57efee3b429d91cddf66edbe6efb9b87'] =
'Cónoce los básicos sobre Live Layer';
$_MODULE['<{doofinder}prestashop>support_tab_f52757c491e99a76cb21926a04bd1c73'] =
'O contacta directamente con nosotros. Estaremos encantados de ayudarte.';
$_MODULE['<{doofinder}prestashop>support_tab_6dcce363217b8653bba30f4edf38ded4'] =
'Email de soporte';
$_MODULE['<{doofinder}prestashop>support_tab_b763aef56692ba323859e536109dc72b'] =
'Puedes depurar o desactivar varias opciones en la pestaña de opciones avanzadas oculta  del módulo. Precaución: ¡Usar solo si eres un usuario experimentado!';
$_MODULE['<{doofinder}prestashop>support_tab_9e2ef841576ac1430c782db2206ca6a6'] =
'Activar la pestaña de opciones Avanzadas';
