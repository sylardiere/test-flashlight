<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{doofinder}prestashop>doofinder_dd31d974a78cdd704acaa6bf15da506c'] =
'Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_537d60a5ce0c6b6cf2d6790d5b38b93f'] =
'Install Doofinder in your shop with no effort';
$_MODULE['<{doofinder}prestashop>doofinder_e499922a91899a55af0659f1f4772e6a'] =
'Are you sure? This will not cancel your account in Doofinder service';
$_MODULE['<{doofinder}prestashop>doofinder_4b87741739092ad3d8ebedd16f51b8fa'] =
'Doofinder search layer';
$_MODULE['<{doofinder}prestashop>doofinder_51c17cc3a1f109327c91c2bab0e21962'] =
'Doofinder search layer in mobile version';
$_MODULE['<{doofinder}prestashop>doofinder_79958197e198decc81fe8357f5e18a56'] =
'Doofinder Store ID';
$_MODULE['<{doofinder}prestashop>doofinder_a0d5c74d196e9447e43b5d35875172dd'] =
'You can find this identifier in our control panel. Inside the side menu labeled \"Store settings\".';
$_MODULE['<{doofinder}prestashop>doofinder_652f52b24a21bd5ff556daeb1c23e304'] =
'Search Layer';
$_MODULE['<{doofinder}prestashop>doofinder_ac094819c47414b269d824497c1ff3ec'] =
'Save Layer Widget Options';
$_MODULE['<{doofinder}prestashop>doofinder_daae36229556815de2395abf51714337'] =
'Data Feed';
$_MODULE['<{doofinder}prestashop>doofinder_c5848d64c88f4174aa2c7a25d06bc044'] =
'Index product prices';
$_MODULE['<{doofinder}prestashop>doofinder_79272d6ac0fc6480115ee98565778947'] =
'If you activate this option you will be able to show the prices of each product in the search results.';
$_MODULE['<{doofinder}prestashop>doofinder_2e50fba97feb0e9b740a5c785d07ab7d'] =
'Show product prices including taxes';
$_MODULE['<{doofinder}prestashop>doofinder_11a4b29c886f33dc95b29c02318e179f'] =
'If you activate this option, the price of the products that will be displayed will be inclusive of taxes.';
$_MODULE['<{doofinder}prestashop>doofinder_73c34b49888ccdf22dd73e7eafc0edd8'] =
'Index the full path of the product category';
$_MODULE['<{doofinder}prestashop>doofinder_cdfda1adef135661c21a248cb159c6f4'] =
'Index product attribute combinations';
$_MODULE['<{doofinder}prestashop>doofinder_e730c40ec1617ecf160fa29d8a1dc05c'] =
'Define which combinations of product attributes you want to index for';
$_MODULE['<{doofinder}prestashop>doofinder_bbf76abf65b7e5530ebf33b0f8a666c9'] =
'Index customized product features';
$_MODULE['<{doofinder}prestashop>doofinder_ebe75aa799359b32559a09eae8594835'] =
'Select features will be shown in feed';
$_MODULE['<{doofinder}prestashop>doofinder_90dce1b992114b5c7ab37ee99ea195ec'] =
'Product Image Size';
$_MODULE['<{doofinder}prestashop>doofinder_435374cdbc1c2cf3b63e9775cbedd00a'] =
'Automatically process product changes';
$_MODULE['<{doofinder}prestashop>doofinder_c2cad3c344198599b69e25634315170d'] =
'Configure when registered product changes are sent to Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_48bf14c419a1d441412510faf39c326d'] =
'Every day';
$_MODULE['<{doofinder}prestashop>doofinder_643bd9766a482fed97aff60a7a4f1b3b'] =
'Every %s minutes';
$_MODULE['<{doofinder}prestashop>doofinder_836f443d97d58d8ec45b18fd574c8933'] =
'Save Data Feed Options';
$_MODULE['<{doofinder}prestashop>doofinder_9dfc5d5738312210c3c75e68a468691d'] =
'Advanced Options';
$_MODULE['<{doofinder}prestashop>doofinder_e0daaf59114081fac112928e638c8d85'] =
'Doofinder Api Key';
$_MODULE['<{doofinder}prestashop>doofinder_f447ac856e7e72435904956e3b15f433'] =
'Region';
$_MODULE['<{doofinder}prestashop>doofinder_c01ae558981823abcbd1489ac81f6fc9'] =
'Enable v9 layer (Livelayer)';
$_MODULE['<{doofinder}prestashop>doofinder_f4f6f81745dcb96aaf1cd38461ba2356'] =
'Debug Mode. Write info logs in doofinder.log file';
$_MODULE['<{doofinder}prestashop>doofinder_b0939b990335e5c6a8f76fa5c81835b3'] =
'CURL disable HTTPS check';
$_MODULE['<{doofinder}prestashop>doofinder_8391131ea151a1b120d9fceef5ad9b9a'] =
'If your server have an untrusted certificate and you have connection problems with the API, please enable this';
$_MODULE['<{doofinder}prestashop>doofinder_bfa398fb4ff673ac66baeedbc80f0b77'] =
'Debug CURL error response';
$_MODULE['<{doofinder}prestashop>doofinder_170246e7e517d7cd317e3a6ae3ebcb4c'] =
'To debug if your server has symptoms of connection problems';
$_MODULE['<{doofinder}prestashop>doofinder_48c07cbd1f0f4b03d59befc3e72e9b87'] =
'Save Internal Search Options';
$_MODULE['<{doofinder}prestashop>doofinder_fcea235fdf24a526070153f5b60355f4'] =
'You\'ve just changed a data feed option. It may be necessary to reprocess the index to apply these changes effectively.';
$_MODULE['<{doofinder}prestashop>doofinder_2378c5bcb7b183304da2a2b94262f024'] =
'Launch reindexing';
$_MODULE['<{doofinder}prestashop>doofinder_039b452cd9646bf1a60dd09146311ee7'] =
'Settings updated!';
$_MODULE['<{doofinder}prestashop>doofinder_00d23a76e43b46dae9ec7aa9dcbebb32'] =
'Enabled';
$_MODULE['<{doofinder}prestashop>doofinder_b9f5c797ebbf55adccdd8539a65a0241'] =
'Disabled';
$_MODULE['<{doofinder}prestashop>configure_ba0801f239c99cb689010161d3ee1471'] =
'On Boarding';
$_MODULE['<{doofinder}prestashop>configure_8cd892b7b97ef9489ae4479d3f4ef0fc'] =
'store';
$_MODULE['<{doofinder}prestashop>configure_db5eb84117d06047c97c9a0191b5fffe'] =
'Support';
$_MODULE['<{doofinder}prestashop>configure_9b6545e4cea9b4ad4979d41bb9170e2b'] =
'Advanced';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_86bbc77fd75ac02c21b84a37b260eadd'] =
'Administration panel';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_23693319f4ed79081952f04729017d15'] =
'Config Doofinder in my shop';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_f6e6bc175f0485d397ee4c1d45c1d01e'] =
'Access the Doofinder dashboard and discover all the functionalities to increase your sales.';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_e77e4aaa7a0d7df358c2f9a8276bee7d'] =
'Go to Doofinder dashboard';
$_MODULE['<{doofinder}prestashop>feed_url_partial_tab_08c1cf7707bb72744cd07192c8580580'] =
'Feed URLs to use on Doofinder Admin panel';
$_MODULE['<{doofinder}prestashop>feed_url_partial_tab_c2052eaf6f39b73a2c74240459fc2615'] =
'Data feed URL for';
$_MODULE['<{doofinder}prestashop>indexation_status_51160de843c8d9ed5564f4f26208c02e'] =
'Doofinder Indexation Status';
$_MODULE['<{doofinder}prestashop>indexation_status_b1d48d617a09cbe4e68eb72c83dea83d'] =
'The product feed is being processed. Depending on the size of the product catalog in the store, this process may take a few minutes.';
$_MODULE['<{doofinder}prestashop>indexation_status_e0dba0265fde532f75126eab6fedb8a8'] =
'Your products may not appear correctly updated in the search results until the process has been completed.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_6b866b4e92effe404fd83e7a7885ad19'] =
'Connection with Doofinder successful.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_deed258a0a8c1f5382450930479ac0fd'] =
'You cannot connect with Doofinder. Please contact your server provider to check your web server internet connection or firewall.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_a4a6b90012834c7cb676c674bf621993'] =
'An error occurred during the installation process. Please contact our support team on';
$_MODULE['<{doofinder}prestashop>onboarding_tab_747e44b01e24ca919d59438ae296b448'] =
'Creating search engines...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f7c1251d5362d2d5d94acc2032a50484'] =
'Recover data feed of your products...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_3339a7d2f65d221bf59b9c25581966f1'] =
'Creating index to search on your site...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_44665e4612000577ba603412b3aa25b2'] =
'Giving a final magic touch...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_659ae688646b0c710802028d1bbc2812'] =
'Reloading page, please wait...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_c594c7071a3f319fc4db4fa2a6e83f5b'] =
'Create this shop in Doofinder';
$_MODULE['<{doofinder}prestashop>onboarding_tab_7edaed702d94d2c7807d20d662c7067a'] =
'I have an account';
$_MODULE['<{doofinder}prestashop>onboarding_tab_4d6db8d5a88bb9c3e6b55bce672e0dd9'] =
'I want to skip the autoinstaller, take me to the module manual configuration.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_ba26552e526b4e94f440ab5a0f7ce65f'] =
'Add a smart search engine to your e-commerce in 5 minutes and with no programming';
$_MODULE['<{doofinder}prestashop>onboarding_tab_1e084cd6e247c0daa8f4004976a10df5'] =
'ABOUT DOOFINDER';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f770abcb4ee19d99e1dfa65fe2504e18'] =
'Among our features are';
$_MODULE['<{doofinder}prestashop>onboarding_tab_fa48c4bc8e56055f4501cab8d53ce068'] =
'Detailed reports on visitor search behaviour';
$_MODULE['<{doofinder}prestashop>onboarding_tab_4562bb888773ad94e6c7e0c2083d8c79'] =
'Faceted search option';
$_MODULE['<{doofinder}prestashop>onboarding_tab_c17910ea7aaac1591ce9f5485f657f4f'] =
'Learning behaviour';
$_MODULE['<{doofinder}prestashop>onboarding_tab_907d3b76d74e77bc7ded86a5e61a0e88'] =
'Merchandising power to set a products positioning';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f06602764717ea3114175e3e5039a42a'] =
'Banner feature for advertising and promoting products, brands and events';
$_MODULE['<{doofinder}prestashop>onboarding_tab_484ebd8da685828c8892dbbb1a570f89'] =
'Options to redirect users to content pages';
$_MODULE['<{doofinder}prestashop>onboarding_tab_8e94cbfc7639e8d47a939179b12a8eac'] =
'Held on our servers for a faster page load time';
$_MODULE['<{doofinder}prestashop>onboarding_tab_18947c4da2bdf6834e993001d003293d'] =
'More than 5000 e-commerce sites over 35 countries are already using it';
$_MODULE['<{doofinder}prestashop>onboarding_tab_d3de93cac749c0caa87290a2a4a7c8a9'] =
'What are you waiting for?';
$_MODULE['<{doofinder}prestashop>support_tab_4c1fee9a2c61bba0f4bbcab7c99948de'] =
'Need help configuring your search engine?';
$_MODULE['<{doofinder}prestashop>support_tab_dfc465ee578939c8760c4aa00d2c7234'] =
'All documentation in one place!';
$_MODULE['<{doofinder}prestashop>support_tab_a0b0d4b4cb7e019561740ca1fe2e9a4a'] =
'Understand how the product feed works to display results in the Doofinder search layer';
$_MODULE['<{doofinder}prestashop>support_tab_6b8f482bb34c8983f0bcb2651b776e9f'] =
'How to add information in the Doofinder search layer';
$_MODULE['<{doofinder}prestashop>support_tab_105dad09bf429ff180f1465aba5b2164'] =
'How to configure the search layer filters';
$_MODULE['<{doofinder}prestashop>support_tab_57efee3b429d91cddf66edbe6efb9b87'] =
'Learn the basics about Live Layer';
$_MODULE['<{doofinder}prestashop>support_tab_f52757c491e99a76cb21926a04bd1c73'] =
'Or contact directly with us. We will be glad to help you';
$_MODULE['<{doofinder}prestashop>support_tab_6dcce363217b8653bba30f4edf38ded4'] =
'Support email';
$_MODULE['<{doofinder}prestashop>support_tab_b763aef56692ba323859e536109dc72b'] =
'You can debug or disable some options on the hidden advanced tab of the module.  Caution: Use only if you are a experienced user!!';
$_MODULE['<{doofinder}prestashop>support_tab_9e2ef841576ac1430c782db2206ca6a6'] =
'Enable advanced module tab options';
