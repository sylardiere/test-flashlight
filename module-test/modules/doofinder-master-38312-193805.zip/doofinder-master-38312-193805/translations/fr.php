<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{doofinder}prestashop>doofinder_dd31d974a78cdd704acaa6bf15da506c'] =
'Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_537d60a5ce0c6b6cf2d6790d5b38b93f'] =
'Ajoutez un moteur de recherche intelligent à votre site en moins de 5 minutes et sans programmation';
$_MODULE['<{doofinder}prestashop>doofinder_e499922a91899a55af0659f1f4772e6a'] =
'Êtes-vous sûr? Cela n\'annulera pas votre compte dans le service Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_4b87741739092ad3d8ebedd16f51b8fa'] =
'Couche de recherche Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_51c17cc3a1f109327c91c2bab0e21962'] =
'Couche de recherche Doofinder dans la version mobile';
$_MODULE['<{doofinder}prestashop>doofinder_79958197e198decc81fe8357f5e18a56'] =
'Doofinder Store ID';
$_MODULE['<{doofinder}prestashop>doofinder_a0d5c74d196e9447e43b5d35875172dd'] =
'Vous trouverez cet identifiant dans votre Panel de Contrôle, sous le menu \"Live Layer\"';
$_MODULE['<{doofinder}prestashop>doofinder_652f52b24a21bd5ff556daeb1c23e304'] =
'LAYER DOOFINDER';
$_MODULE['<{doofinder}prestashop>doofinder_ac094819c47414b269d824497c1ff3ec'] =
'Sauvegarder les options du Layer';
$_MODULE['<{doofinder}prestashop>doofinder_daae36229556815de2395abf51714337'] =
'FLUX PRODUIT';
$_MODULE['<{doofinder}prestashop>doofinder_c5848d64c88f4174aa2c7a25d06bc044'] =
'Indexation des prix des produits';
$_MODULE['<{doofinder}prestashop>doofinder_79272d6ac0fc6480115ee98565778947'] =
'Si vous activez cette option, vous pourrez afficher les prix de chaque produit dans les résultats de la recherche.';
$_MODULE['<{doofinder}prestashop>doofinder_2e50fba97feb0e9b740a5c785d07ab7d'] =
'Afficher les prix TTC des produits';
$_MODULE['<{doofinder}prestashop>doofinder_11a4b29c886f33dc95b29c02318e179f'] =
'Si vous activez cette option, le prix des produits à afficher sera TTC.';
$_MODULE['<{doofinder}prestashop>doofinder_73c34b49888ccdf22dd73e7eafc0edd8'] =
'Indexer le chemin complet de la catégorie de produits';
$_MODULE['<{doofinder}prestashop>doofinder_cdfda1adef135661c21a248cb159c6f4'] =
'Indexer les combinaisons d\'attributs de produits';
$_MODULE['<{doofinder}prestashop>doofinder_e730c40ec1617ecf160fa29d8a1dc05c'] =
'Définissez les combinaisons d\'attributs de produits que vous souhaitez indexer';
$_MODULE['<{doofinder}prestashop>doofinder_bbf76abf65b7e5530ebf33b0f8a666c9'] =
'Index des caractéristiques des produits personnalisés';
$_MODULE['<{doofinder}prestashop>doofinder_ebe75aa799359b32559a09eae8594835'] =
'Sélectionner les caractéristiques à afficher dans le flux';
$_MODULE['<{doofinder}prestashop>doofinder_90dce1b992114b5c7ab37ee99ea195ec'] =
'Taille de l’image du produit';
$_MODULE['<{doofinder}prestashop>doofinder_435374cdbc1c2cf3b63e9775cbedd00a'] =
'Traiter automatiquement les changements de produits';
$_MODULE['<{doofinder}prestashop>doofinder_c2cad3c344198599b69e25634315170d'] =
'Configurer le moment où les changements de produits enregistrés sont envoyés à Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_48bf14c419a1d441412510faf39c326d'] =
'Chaque jour';
$_MODULE['<{doofinder}prestashop>doofinder_643bd9766a482fed97aff60a7a4f1b3b'] =
'Toutes les %s minutes';
$_MODULE['<{doofinder}prestashop>doofinder_836f443d97d58d8ec45b18fd574c8933'] =
'Sauvegarder les options du flux produit';
$_MODULE['<{doofinder}prestashop>doofinder_9dfc5d5738312210c3c75e68a468691d'] =
'Advanced Options';
$_MODULE['<{doofinder}prestashop>doofinder_e0daaf59114081fac112928e638c8d85'] =
'Clé API de Doofinder';
$_MODULE['<{doofinder}prestashop>doofinder_f447ac856e7e72435904956e3b15f433'] =
'Région';
$_MODULE['<{doofinder}prestashop>doofinder_c01ae558981823abcbd1489ac81f6fc9'] =
'Activer la layer v9 (Livelayer)';
$_MODULE['<{doofinder}prestashop>doofinder_f4f6f81745dcb96aaf1cd38461ba2356'] =
'Debug Mode. Write info logs in doofinder.log file';
$_MODULE['<{doofinder}prestashop>doofinder_b0939b990335e5c6a8f76fa5c81835b3'] =
'CURL disable HTTPS check';
$_MODULE['<{doofinder}prestashop>doofinder_8391131ea151a1b120d9fceef5ad9b9a'] =
'If your server have an untrusted certificate and you have connection problems with the API, please enable this';
$_MODULE['<{doofinder}prestashop>doofinder_bfa398fb4ff673ac66baeedbc80f0b77'] =
'Debug CURL error response';
$_MODULE['<{doofinder}prestashop>doofinder_170246e7e517d7cd317e3a6ae3ebcb4c'] =
'To debug if your server has symptoms of connection problems';
$_MODULE['<{doofinder}prestashop>doofinder_48c07cbd1f0f4b03d59befc3e72e9b87'] =
'Sauvegarder les options de recherche interne';
$_MODULE['<{doofinder}prestashop>doofinder_fcea235fdf24a526070153f5b60355f4'] =
'Vous venez de modifier une option de flux de données. L\'application efficace de ces modifications peut nécessiter un retraitement de l\'index.';
$_MODULE['<{doofinder}prestashop>doofinder_2378c5bcb7b183304da2a2b94262f024'] =
'Exécuter la réindexation';
$_MODULE['<{doofinder}prestashop>doofinder_039b452cd9646bf1a60dd09146311ee7'] =
'Paramètres mis à jour!';
$_MODULE['<{doofinder}prestashop>doofinder_00d23a76e43b46dae9ec7aa9dcbebb32'] =
'Activé';
$_MODULE['<{doofinder}prestashop>doofinder_b9f5c797ebbf55adccdd8539a65a0241'] =
'Désactivé';
$_MODULE['<{doofinder}prestashop>configure_ba0801f239c99cb689010161d3ee1471'] =
'ON BOARDING';
$_MODULE['<{doofinder}prestashop>configure_8cd892b7b97ef9489ae4479d3f4ef0fc'] =
'boutique';
$_MODULE['<{doofinder}prestashop>configure_db5eb84117d06047c97c9a0191b5fffe'] =
'SUPPORT';
$_MODULE['<{doofinder}prestashop>configure_9b6545e4cea9b4ad4979d41bb9170e2b'] =
'ADVANCED';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_86bbc77fd75ac02c21b84a37b260eadd'] =
'Panneau d\'administration';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_23693319f4ed79081952f04729017d15'] =
'Configurer Doofinder dans ma boutique';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_f6e6bc175f0485d397ee4c1d45c1d01e'] =
'Accédez au tableau de bord Doofinder et découvrez toutes les fonctionnalités pour augmenter vos ventes.';
$_MODULE['<{doofinder}prestashop>configure_administration_panel_e77e4aaa7a0d7df358c2f9a8276bee7d'] =
'Accéder au tableau de bord de Doofinder';
$_MODULE['<{doofinder}prestashop>feed_url_partial_tab_08c1cf7707bb72744cd07192c8580580'] =
'Voici vos Url de flux produit à insérer dans le back office de Doofinder';
$_MODULE['<{doofinder}prestashop>feed_url_partial_tab_c2052eaf6f39b73a2c74240459fc2615'] =
'Url du flux produit pour';
$_MODULE['<{doofinder}prestashop>indexation_status_51160de843c8d9ed5564f4f26208c02e'] =
'Statut d\'indexation de Doofinder';
$_MODULE['<{doofinder}prestashop>indexation_status_b1d48d617a09cbe4e68eb72c83dea83d'] =
'Le flux de produits est en cours de traitement. Selon la taille du catalogue de produits de la boutique, ce processus peut prendre quelques minutes.';
$_MODULE['<{doofinder}prestashop>indexation_status_e0dba0265fde532f75126eab6fedb8a8'] =
'Il se peut que vos produits n\'apparaissent pas correctement mis à jour dans les résultats de recherche tant que le processus n\'est pas terminé.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_6b866b4e92effe404fd83e7a7885ad19'] =
'Connection with Doofinder successful.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_deed258a0a8c1f5382450930479ac0fd'] =
'You cannot connect with Doofinder. Please contact your server provider to check your web server internet connection or firewall.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_a4a6b90012834c7cb676c674bf621993'] =
'Une erreur s’est produite durant l’installation. Veuillez contacter notre support à';
$_MODULE['<{doofinder}prestashop>onboarding_tab_747e44b01e24ca919d59438ae296b448'] =
'Création de moteurs de recherche ...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f7c1251d5362d2d5d94acc2032a50484'] =
'Collecte de catalogues de produits ...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_3339a7d2f65d221bf59b9c25581966f1'] =
'Création d\'index de recherche sur le site Web ...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_44665e4612000577ba603412b3aa25b2'] =
'Donner la dernière touche magique finale ...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_659ae688646b0c710802028d1bbc2812'] =
'Rechargement de la page, veuillez patienter ...';
$_MODULE['<{doofinder}prestashop>onboarding_tab_c594c7071a3f319fc4db4fa2a6e83f5b'] =
'Create this shop in Doofinder';
$_MODULE['<{doofinder}prestashop>onboarding_tab_7edaed702d94d2c7807d20d662c7067a'] =
'J\'ai un compte';
$_MODULE['<{doofinder}prestashop>onboarding_tab_4d6db8d5a88bb9c3e6b55bce672e0dd9'] =
'Je veux ignorer l\'installateur automatique, amenez-moi à la configuration manuelle  du module.';
$_MODULE['<{doofinder}prestashop>onboarding_tab_ba26552e526b4e94f440ab5a0f7ce65f'] =
'Ajoutez un moteur de recherche intelligent à votre site en moins de 5 minutes et  sans programmation';
$_MODULE['<{doofinder}prestashop>onboarding_tab_1e084cd6e247c0daa8f4004976a10df5'] =
'A PROPOS DE DOOFINDER';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f770abcb4ee19d99e1dfa65fe2504e18'] =
'Doofinder vous offre';
$_MODULE['<{doofinder}prestashop>onboarding_tab_fa48c4bc8e56055f4501cab8d53ce068'] =
'Un rapport statistique détaillé du comportement de vos consommateurs';
$_MODULE['<{doofinder}prestashop>onboarding_tab_4562bb888773ad94e6c7e0c2083d8c79'] =
'Une navigation à facette';
$_MODULE['<{doofinder}prestashop>onboarding_tab_c17910ea7aaac1591ce9f5485f657f4f'] =
'Une autocomplétion de la recherche';
$_MODULE['<{doofinder}prestashop>onboarding_tab_907d3b76d74e77bc7ded86a5e61a0e88'] =
'Des outils de Merchandising pour mettre en avant vos produits favoris';
$_MODULE['<{doofinder}prestashop>onboarding_tab_f06602764717ea3114175e3e5039a42a'] =
'Mis en place de bannière promotionnelle';
$_MODULE['<{doofinder}prestashop>onboarding_tab_484ebd8da685828c8892dbbb1a570f89'] =
'Redirection vers des pages marques ou contenus';
$_MODULE['<{doofinder}prestashop>onboarding_tab_8e94cbfc7639e8d47a939179b12a8eac'] =
'Tout passe par nos serveurs, ce qui vous garantit un chargement extrêmement rapide';
$_MODULE['<{doofinder}prestashop>onboarding_tab_18947c4da2bdf6834e993001d003293d'] =
'Plus de 5000 e-commerces nous font confiance';
$_MODULE['<{doofinder}prestashop>onboarding_tab_d3de93cac749c0caa87290a2a4a7c8a9'] =
'Qu’attendez-vous?';
$_MODULE['<{doofinder}prestashop>support_tab_4c1fee9a2c61bba0f4bbcab7c99948de'] =
'Vous avez besoin d’aide pour configurer votre moteur de recherche?';
$_MODULE['<{doofinder}prestashop>support_tab_dfc465ee578939c8760c4aa00d2c7234'] =
'Toute la documentation nécessaire';
$_MODULE['<{doofinder}prestashop>support_tab_a0b0d4b4cb7e019561740ca1fe2e9a4a'] =
'Comprendre comment le flux de produits fonctionne pour afficher les résultats dans la couche de recherche de Doofinder';
$_MODULE['<{doofinder}prestashop>support_tab_6b8f482bb34c8983f0bcb2651b776e9f'] =
'Comment ajouter des informations dans la couche de recherche de Doofinder ?';
$_MODULE['<{doofinder}prestashop>support_tab_105dad09bf429ff180f1465aba5b2164'] =
'Comment configurer les filtres de la couche de recherche';
$_MODULE['<{doofinder}prestashop>support_tab_57efee3b429d91cddf66edbe6efb9b87'] =
'Apprendre les bases de Live Layer';
$_MODULE['<{doofinder}prestashop>support_tab_f52757c491e99a76cb21926a04bd1c73'] =
'Ou contacter directement notre support, nous serons ravis de vous guider';
$_MODULE['<{doofinder}prestashop>support_tab_6dcce363217b8653bba30f4edf38ded4'] =
'Mail de notre support';
$_MODULE['<{doofinder}prestashop>support_tab_b763aef56692ba323859e536109dc72b'] =
'Vous pouvez déboguer ou désactiver diverses options dans l\'onglet caché des options avancées du module. Attention : à n\'utiliser que si vous êtes un utilisateur expérimenté !';
$_MODULE['<{doofinder}prestashop>support_tab_9e2ef841576ac1430c782db2206ca6a6'] =
' Activer les options de l\'onglet de module avancé';
