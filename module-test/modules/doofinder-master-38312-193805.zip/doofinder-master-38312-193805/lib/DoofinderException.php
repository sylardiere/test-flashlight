<?php
/**
 * @author    Doofinder
 * @copyright Doofinder
 * @license   GPLv3
 */
class DoofinderException extends Exception
{
}
